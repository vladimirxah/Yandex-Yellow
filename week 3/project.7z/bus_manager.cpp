/*
 * bus_manager.cpp
 *
 *  Created on: 12 апр. 2019 г.
 *      Author: goncharov
 */

#include "bus_manager.h"

void BusManager::AddBus(const string& bus, const vector<string>& stops) {
	// Реализуйте этот метод
	buses_to_stops[bus] = stops;
	vector<string>& stops2 = buses_to_stops[bus];
	for (string& stop : stops2) {
		stops_to_buses[stop].push_back(bus);
//			контрольный вывод
/*			cout << "Add " << bus << " for stop " << stop << endl;*/
	}
//		контрольный вывод
/*		cout << "Added buses for stops:" << endl;
	for (const auto& st : stops_to_buses) {
		cout << st.first << ": ";
		for (const auto& bs : st.second) {
			cout << bs << " ";
		}
		cout << "\n";
	}*/
}

BusesForStopResponse BusManager::GetBusesForStop(const string& stop) const {
	// Реализуйте этот метод
	BusesForStopResponse stopbuses;
/*  	for (const auto& item : stops_to_buses) {
		cout << item.first << ": ";
		for (const auto& bus : item.second) {
			cout << bus << " ";
		}
		cout << endl;
	}
	cout << "Size of stops_to_buses is " << stops_to_buses.size() << endl;
	if (stops_to_buses.count(stop) > 0) {
		auto s = stops_to_buses.at(stop).size();
		cout << "Size is " << s << endl;
	} else {
		cout << "Count for " << stop << " is 0." << endl;
		return stopbuses;
	}*/
	if (stops_to_buses.count(stop) == 0) return stopbuses;
	const vector<string>& stbuses = stops_to_buses.at(stop);
//  	cout << stbuses.size() << endl;
	for (const auto& bus : stbuses) {
		stopbuses.buses.push_back(bus);
	}
	return stopbuses;
}

StopsForBusResponse BusManager::GetStopsForBus(const string& bus) const {
	// Реализуйте этот метод
	StopsForBusResponse r;
	if (buses_to_stops.count(bus) == 0) return r;
	for (const string& stop : buses_to_stops.at(bus)) {
		string line = "";
		line = "Stop " + stop + ": ";
		if (stops_to_buses.at(stop).size() == 1) {
			line.append("no interchange");
		} else {
			for (const string& other_bus : stops_to_buses.at(stop)) {
				if (bus != other_bus) {
					line.append(other_bus + " ");
				}
			}
		}
		r.vec.push_back(line);
	}
	return r;
}

AllBusesResponse BusManager::GetAllBuses() const {
	// Реализуйте этот метод
	AllBusesResponse allbuses;
	for (const auto& bus_item : buses_to_stops) {
		string line;
		line = line + "Bus " + bus_item.first + ": ";
		for (const string& stop : bus_item.second) {
//				cout << "next stop is " << stop << " ";
			line = line + stop + " ";
		}
		line.push_back('\n');
//			cout << line << " new line" << endl;
		allbuses.buses.push_back(line);
	}
	return allbuses;
}
