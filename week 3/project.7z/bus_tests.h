/*
 * bus_tests.h
 *
 *  Created on: 12 апр. 2019 г.
 *      Author: goncharov
 */

#pragma once

//#include <iostream>
#include <sstream>
#include <vector>

#include "test_runner.h"

void TestInOperator ();
