/*
 * bus_tests.cpp
 *
 *  Created on: 12 апр. 2019 г.
 *      Author: goncharov
 */

#include "bus_tests.h"
#include "query.h"

using namespace std;

void TestInOperator () {
	Query q;
	istringstream is1("NEW_BUS 32 3 Tolstopaltsevo Marushkino Vnukovo");
	is1 >> q;
	if (q.type == QueryType::NewBus) {
		cout << "Type pass. ";
	} else {
		cout << "Type fail. ";
	}
	if (q.bus == "32") {
		cout << "Bus pass. ";
	} else {
		cout << "Bus fail. ";
	}
	if (q.stop == "3") {
		cout << "Num stop pass. ";
	} else {
		cout << "Num stop fail. ";
	}
	vector<string> vec = {"Tolstopaltsevo", "Marushkino", "Vnukovo"};
	if (q.stops == vec) {
		cout << "Vec stops pass. " << endl;
	} else {
		cout << "Vec stops fail. " << endl;
	}

	Query q2;
	istringstream is2("BUSES_FOR_STOP Vnukovo");
	is2 >> q2;
	if (q2.type == QueryType::BusesForStop) {
		cout << "Type pass. ";
	} else {
		cout << "Type fail. ";
	}
	if (q2.bus.empty()) {
		cout << "Bus pass. ";
	} else {
		cout << "Bus fail. ";
	}
	if (q2.stop.empty()) {
		cout << "Num stop pass. ";
	} else {
		cout << "Num stop fail. ";
	}
	vector<string> vec2 = {"Vnukovo"};
	if (q2.stops == vec2) {
		cout << "Vec stops pass. " << endl;
	} else {
		cout << "Vec stops fail. " << endl;
	}
}
