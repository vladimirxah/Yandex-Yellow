/*
 * query.cpp
 *
 *  Created on: 12 апр. 2019 г.
 *      Author: goncharov
 *
 определение istream& operator >> (istream& is, Query& q);

 */

#include "query.h"

istream& operator >> (istream& is, Query& q) {
  // Реализуйте эту функцию
		string type;
		is >> type;
		map< string, QueryType> enumResolver = {{"NEW_BUS", QueryType::NewBus}, {"BUSES_FOR_STOP", QueryType::BusesForStop}, {"STOPS_FOR_BUS", QueryType::StopsForBus}, {"ALL_BUSES", QueryType::AllBuses}};
		q.type = enumResolver[type];
		string bus, stop;
		vector<string> stops;
		switch (q.type) {
			case QueryType::NewBus:
				is >> bus >> stop;
				for (auto i = 0; i < stoi(stop); ++i)
				{
					string newstop = "";
					is >> newstop;
					stops.push_back(newstop);
				}
				q = {enumResolver[type], bus, stop, stops};
				break;
			case QueryType::BusesForStop:
				{
					string searchstop;
					is >> searchstop;
					q.stop = searchstop;
				}
				break;
			case QueryType::StopsForBus:
				is >> bus;
				q.bus = bus;
				break;
			case QueryType::AllBuses:
				break;
		}
	return is;
}
