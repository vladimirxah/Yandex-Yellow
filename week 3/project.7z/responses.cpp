/*
 * responses.cpp
 *
 *  Created on: 12 апр. 2019 г.
 *      Author: goncharov
 */

#include "responses.h"

ostream& operator << (ostream& os, const BusesForStopResponse& r) {
  // Реализуйте эту функцию
	if (r.buses.empty()) {
		os << "No stop";
	} else {
		for (const string& bus : r.buses) {
			os << bus << " ";
		}
//		os << endl;
	}
  return os;
}

ostream& operator << (ostream& os, const StopsForBusResponse& r) {
  // Реализуйте эту функцию
	if (r.vec.empty()) {
		os << "No bus";
	} else {
		for (const string& bus_item : r.vec) {
			os << bus_item << endl;
		}
	}
	return os;
}

ostream& operator << (ostream& os, const AllBusesResponse& r) {
  // Реализуйте эту функцию
	if (r.buses.empty()) {
		os << "No buses";
	} else {
		for (const string& bus_item : r.buses) {
			os << bus_item;
		}
	}
	return os;
}
